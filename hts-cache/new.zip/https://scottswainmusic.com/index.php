<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="/application/themes/scottswain/css/bootstrap-modified.css">
	<link href="https://fonts.googleapis.com/css?family=Merriweather:400,400i,900,900i" rel="stylesheet"> 
	<link href="/application/files/cache/css/scottswain/scott.css?ts=1627574395" rel="stylesheet" type="text/css" media="all">	<noscript>		<style type="text/css">.ccm-page #contact {height:auto;}</style>
	</noscript>    
<title>Home :: Scott Swain</title>

<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="generator" content="concrete5 - 8.3.2"/>
<meta name="msapplication-TileImage" content="http://scottswainmusic.com/application/files/6715/2064/6132/icon144x144.png"/>
<link rel="shortcut icon" href="http://scottswainmusic.com/application/files/1915/2064/6131/icon16x16.ico" type="image/x-icon"/>
<link rel="icon" href="http://scottswainmusic.com/application/files/1915/2064/6131/icon16x16.ico" type="image/x-icon"/>
<link rel="apple-touch-icon" href="http://scottswainmusic.com/application/files/5815/2064/6132/icon57x57.png"/>
<link rel="canonical" href="http://scottswainmusic.com/">
<script type="text/javascript">
    var CCM_DISPATCHER_FILENAME = "/index.php";
    var CCM_CID = 1;
    var CCM_EDIT_MODE = false;
    var CCM_ARRANGE_MODE = false;
    var CCM_IMAGE_PATH = "/concrete/images";
    var CCM_TOOLS_PATH = "/index.php/tools/required";
    var CCM_APPLICATION_URL = "http://scottswainmusic.com";
    var CCM_REL = "";
    var CCM_ACTIVE_LOCALE = "en_GB";
</script>

<style type="text/css" data-area-style-area-handle="Featured17" data-block-style-block-id="313" data-style-set="62">.ccm-custom-style-container.ccm-custom-style-featured17-313{text-align:center}</style><style type="text/css" data-area-style-area-handle="Introduction" data-style-set="25">.ccm-custom-style-introduction{text-align:center}</style><style type="text/css" data-area-style-area-handle="Main" data-style-set="29">.ccm-custom-style-main{text-align:center}</style><style type="text/css" data-area-style-area-handle="Main" data-block-style-block-id="49" data-style-set="10">.ccm-custom-style-container.ccm-custom-style-main-49{padding-right:100px;padding-left:100px}</style><style type="text/css" data-area-style-area-handle="Main" data-block-style-block-id="72" data-style-set="19">.ccm-custom-style-container.ccm-custom-style-main-72{margin-bottom:10px}</style>
<style type="text/css" data-area-style-area-handle="Main" data-block-style-block-id="323" data-style-set="37">.ccm-custom-style-container.ccm-custom-style-main-323{margin-top:20px;margin-bottom:15px}</style>
<style type="text/css" data-area-style-area-handle="Main" data-block-style-block-id="325" data-style-set="49">.ccm-custom-style-container.ccm-custom-style-main-325{background-color:rgb(196, 34, 50);padding-top:15px;padding-right:15px;padding-bottom:15px;padding-left:15px}</style>
<style type="text/css" data-area-style-area-handle="Main" data-block-style-block-id="299" data-style-set="31">.ccm-custom-style-container.ccm-custom-style-main-299{text-align:center}</style>
<style type="text/css" data-area-style-area-handle="Main" data-block-style-block-id="247" data-style-set="60">.ccm-custom-style-container.ccm-custom-style-main-247{text-align:center}</style>
<link href="/concrete/css/font-awesome.css" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript" src="/concrete/js/jquery.js"></script>
<!--[if lt IE 9]><script type="text/javascript" src="/concrete/js/ie/html5-shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script type="text/javascript" src="/concrete/js/ie/respond.js"></script><![endif]-->
	
	<style type="text/css">
		div.ccm-page header #cover {
			background-image: url(/application/files/5115/2051/1648/cover-image-1.jpg);
		}
	</style>
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
            var msViewportStyle = document.createElement('style');
            msViewportStyle.appendChild(
                document.createTextNode(
                    '@-ms-viewport{width:auto!important}'
                )
            );
            document.querySelector('head').appendChild(msViewportStyle);
        }
    </script>
</head>
<body>

<div class="ccm-page page-type-page page-template-full">
<section id="contact">
	<div class="container">
		<div class="row">
            <div class="col-md-6">
				

    <h2>Contact</h2>



    <div class="ccm-block-express-form">
            <div class="ccm-form">
            <a name="form308"></a>

            
            

            <form enctype="multipart/form-data" class="form-stacked" method="post" action="http://scottswainmusic.com/submit/308#form308">
            
<input type="hidden" name="express_form_id" value="70cff801-251c-11e8-83ed-fdb697d4626d">
<input type="hidden" name="ccm_token" value="1791537778:66d6f84b27c8469c68eb773825e1b91f" />
<div class="ccm-dashboard-express-form">
    
        <fieldset>
            
            
<div class="form-group">
            <label class="control-label">Your name</label>
    
            <span class="text-muted small">Required</span>
    
    <input type="text" id="akID[25][value]" name="akID[25][value]" value="" placeholder="" class="form-control ccm-input-text" /></div>

<div class="form-group">
            <label class="control-label">Your email address</label>
    
            <span class="text-muted small">Required</span>
    
    <input type="email" id="akID[26][value]" name="akID[26][value]" value="" class="form-control ccm-input-email" /></div>

<div class="form-group">
            <label class="control-label">Your message</label>
    
            <span class="text-muted small">Required</span>
    
    
    <textarea id="akID[27][value]" name="akID[27][value]" rows="5" class="form-control"></textarea>
</div>
        </fieldset>
    </div>
                <div class="form-group captcha">
                    <label for="ccm-captcha-code" class="control-label">Please type the letters and numbers shown in the image. Click the image to see another captcha.</label>                    <div><div><img class="ccm-captcha-image" onclick="this.src = this.src.replace(/([?&amp;]nocache=)(\d+)/, &#039;$1&#039; + ((new Date()).getTime()))" width="190" height="60" src="http://scottswainmusic.com/ccm/system/captcha/picture?nocache=1791537778660" alt="Captcha Code"></div></div>
                    <div><div><input id="ccm-captcha-code" class="form-control ccm-input-captcha" required="required" type="text" name="ccmCaptchaCode"></div><br /></div>
                </div>
            
            <div class="form-actions">
                <button type="submit" name="Submit" class="btn btn-primary">Send</button>
            </div>

            </form>

        </div>
    </div>
			</div>
			<div class="col-md-4 col-md-offset-2 visible-md-block visible-lg-block social-links">
				

    <p><span class="social-icons spaced"><a href="http://www.facebook.com/scottswainmusic"><span><i aria-hidden="true" class="fa fa-facebook"></i></span></a> <a href="https://twitter.com/scottswainmusic"><span><i aria-hidden="true" class="fa fa-twitter"></i></span></a> <a href="http://www.soundcloud.com/scottswainmusic"><span><i aria-hidden="true" class="fa fa-soundcloud"></i></span></a> <a href="https://www.reverbnation.com/scottswain"><span><i aria-hidden="true" class="fa fa-star"></i></span></a> <a href="https://www.instagram.com/scottswainmusic/"><span><i aria-hidden="true" class="fa fa-instagram"></i></span></a> </span></p>

<div><span class="social-icons spaced"><a href="https://open.spotify.com/artist/1jOlusZ5KCQkiHsrlXmAlT"><span><i aria-hidden="true" class="fa fa-spotify"></i></span></a></span></div>

			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				

        <div class="ccm-custom-style-container ccm-custom-style-main-86 contact-close"
            >
    <div style="text-align: center;"><i aria-hidden="true" class="fa fa-caret-up"></i><br />
Close</div>

    </div>
			</div>
		</div>
	</div>
</section>
<header>
	<div id="site-header">
		<div class="container">
			<div class="row">
				<div class="col-sm-12" id="site-header-title">
					

        <div class="ccm-custom-style-container ccm-custom-style-main-49"
            >
    <picture><!--[if IE 9]><video style='display: none;'><![endif]--><!--[if IE 9]></video><![endif]--><img src="/application/files/7615/2038/3193/logo-bw.png" alt="Scott Swain" class="ccm-image-block img-responsive bID-49"></picture>
    </div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12" id="site-header-nav">
					

    <ul class="nav"><li class="nav-selected nav-path-selected"><a href="http://scottswainmusic.com/" target="_self" class="nav-selected nav-path-selected">Home</a></li><li class=""><a href="http://scottswainmusic.com/about" target="_self" class="">About</a></li><li class=""><a href="http://scottswainmusic.com/music" target="_self" class="">Music</a></li><li class=""><a href="#contact" target="_self" class="">Contact</a></li></ul>
				</div>
			</div>
		</div>
	</div>

	<div id="cover">
		        
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-lg-offset-1 col-md-5 col-md-offset-1 col-sm-6 col-sm-offset-1 col-xs-7 col-xs-offset-2">
                    

    

        <div class="ccm-custom-style-container ccm-custom-style-main-323 panel-black"
            >
    <p style="text-align: center;margin:0;"><strong>New Single Available Now:</strong></p>

<p style="text-align: center;margin:0;font-size: 115%;line-height:1.5em;"><a href="https://on.soundcloud.com/26un22Gd2H0ezRGPaH"><b><i>Here&#39;s To Going Forward</i></b></a></p>

<p style="text-align: center;line-height:1.5em;font-size: 75%;"><strong><span>Available across all streaming platforms&nbsp;</span></strong></p>

    </div>


        <div class="ccm-custom-style-container ccm-custom-style-main-325 center-block"
            >
    <a href="https://resonatingwoodrecordings.bandcamp.com/album/goodbye-country-goodbye-home" target="_blank"><picture><!--[if IE 9]><video style='display: none;'><![endif]--><!--[if IE 9]></video><![endif]--><img src="/application/files/5117/6622/5123/HTGF_X.jpg" alt="" class="ccm-image-block img-responsive bID-325" title="Play now"></picture></a>
    </div>

                </div>
            </div>
        </div>
	</div>
</header>
<main>
	<div id="main">
	<div
class="ccm-custom-style-main"
>


<div class="container"><div class="row"><div class="col-sm-12">        <div class="ccm-custom-style-container ccm-custom-style-main-335 intro"
            >
    <p>&quot;An innovative and poignant songwriter with a sound akin to the dark splendour of The National.&quot; -&nbsp;<a href="http://www.famemagazine.co.uk/scott-swains-ep-goodbye-country-goodbye-home/" target="_blank">Fame Magazine</a></p>

<p>&ldquo;A spiritual edge beneath the cinematic darkness.&rdquo; - <a href="https://karlismyunkle.com/2025/11/28/scott-swain-takes-us-on-a-metaphorical-trip-warning-how-easily-we-can-be-lulled-into-danger-by-false-security-with-dramatic-new-single-theres-something-in-the-wind/">KIMU</a></p>

<p>&ldquo;A moody, introspective artist with a unique alt-cinematic voice.&rdquo; - <a href="https://www.goodmusicradar.com/review/scott-swain-theres-something-in-the-wind/">Good Music Radar</a></p>

<p>&quot;A dark, immersive soundscape that haunts long after it ends.&rdquo; - <a href="https://www.edgarallanpoets.com/theres-something-in-the-wind-is-scott-swains-single-out-now/">Edgar Allan Poets</a></p>

<p>&ldquo;A genre-defying artist whose cinematic soundscapes draw from film, emotion and atmosphere.&rdquo; - <a href="https://www.withguitars.com/scott-swain-shares-its-too-late/">With Guitars</a></p>

</div></div></div>    </div>


<div class="container"><div class="row"><div class="col-sm-12">    

        <div class="ccm-custom-style-container ccm-custom-style-main-299"
            >
    <p><span class="social-icons spaced"><a href="http://www.facebook.com/scottswainmusic"><span><i aria-hidden="true" class="fa fa-facebook"></i></span></a> <a href="https://twitter.com/scottswainmusic"><span><i aria-hidden="true" class="fa fa-twitter"></i></span></a> <a href="http://www.soundcloud.com/scottswainmusic"><span><i aria-hidden="true" class="fa fa-soundcloud"></i></span></a> <a href="https://www.reverbnation.com/scottswain"><span><i aria-hidden="true" class="fa fa-star"></i></span></a> <a href="https://www.instagram.com/scottswainmusic/"><span><i aria-hidden="true" class="fa fa-instagram"></i></span></a> <a href="https://open.spotify.com/artist/1jOlusZ5KCQkiHsrlXmAlT"><span><i aria-hidden="true" class="fa fa-spotify"></i></span></a></span></p>

    </div>

</div></div></div></div>	</div>
    
    	<div id="featured">
	

<div class="container"><div class="row"><div class="col-sm-12">    <h2>Music</h2>

</div></div></div>

<div class="container"><div class="row"><div class="col-sm-12">    <div class="row"><div class="col-sm-8">

        <div class="ccm-custom-style-container ccm-custom-style-featured17-313"
            >
    <iframe data-testid="embed-iframe" style="border-radius:12px" src="https://open.spotify.com/embed/artist/1jOlusZ5KCQkiHsrlXmAlT?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
    </div>
</div><div class="col-sm-4"></div></div>
</div></div></div>	</div>
    	
		
	<div id="page-footer">
	

<div class="container"><div class="row"><div class="col-sm-12">    

    <p style="text-align: center;">Subscribe to Scott&rsquo;s newsletter for exclusive news and offers:</p>



        <div class="ccm-custom-style-container ccm-custom-style-main-247"
            >
    <!-- Begin MailChimp Signup Form -->
<div id="mc_embed_signup">
<form action="https://scottswainmusic.us14.list-manage.com/subscribe/post?u=7dc13e1266b881f41a3e6b285&amp;id=3cbd892634" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate form-inline" target="_blank" novalidate>
    <div id="mc_embed_signup_scroll">
	
        <div class="mc-field-group">
        	<label class="sr-only" for="mce-EMAIL">Your email address</label>
            <input type="email" style="margin-bottom:5px;" name="EMAIL" class="form-control" id="mce-EMAIL" placeholder="Your email address">
             <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups -->
            <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_7dc13e1266b881f41a3e6b285_3cbd892634" tabindex="-1" value=""></div>
            <button type="submit" style="margin-bottom:5px;" class="btn btn-primary" name="subscribe" id="mc-embedded-subscribe">Subscribe</button>
        </div>
    	<div id="mce-responses" class="clear">
    		<div class="response" id="mce-error-response" style="display:none"></div>
    		<div class="response" id="mce-success-response" style="display:none"></div>
    	</div>   
    </div>
</form>
</div>
<!--End mc_embed_signup-->
    </div>

</div></div></div>	</div>
</main>


<footer id="footer-theme">
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					

        <div class="ccm-custom-style-container ccm-custom-style-main-72 center-block"
            >
    <picture><!--[if IE 9]><video style='display: none;'><![endif]--><!--[if IE 9]></video><![endif]--><img src="/application/files/1315/2046/6490/logo-ss.png" alt="" class="ccm-image-block img-responsive bID-72"></picture>
    </div>
				</div>
				<div class="col-sm-12">
					

    <p>Copyright &copy; 2025&nbsp;Scott Swain | Website: <a href="http://www.gooberlicious.co.uk/" target="_blank">This is Gooberlicious</a></p>

				</div>
			</div>
		</div>
	</section>
</footer>


</div>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-114280316-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-114280316-1');
</script><script type="text/javascript" src="/application/files/cache/js/52f713e6fbf7fd99167f6e4a76dc21291b0c4b7e.js" data-source="/concrete/js/picturefill.js /concrete/blocks/image/view.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.20.4/TweenMax.min.js"></script>
<script src="/application/themes/scottswain/js/scott.js" type="text/javascript"></script>
</body>
</html>
